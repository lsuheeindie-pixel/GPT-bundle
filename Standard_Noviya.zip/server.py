
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from noviya_brain import NoviyaBrain

AI = NoviyaBrain()

class Handler(BaseHTTPRequestHandler):
    def _ok(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_POST(self):
        length = int(self.headers["Content-Length"])
        data = json.loads(self.rfile.read(length))

        if self.path == "/chat":
            msg = data["message"]
            reply = AI.process(msg)
            self._ok()
            self.wfile.write(json.dumps({"reply": reply}).encode())

        elif self.path == "/persona":
            persona = data["persona"]
            ok = AI.set_persona(persona)
            self._ok()
            self.wfile.write(json.dumps({"ok": ok}).encode())

        elif self.path == "/memory":
            self._ok()
            self.wfile.write(json.dumps({"memory": AI.memory.recall()}).encode())

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "POST")
        self.end_headers()

print("Standard Noviya running on http://localhost:8000")
HTTPServer(("0.0.0.0", 8000), Handler).serve_forever()
